package application;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import entities.Aluno;
import jdbc.AlunoJDBC;

public class Program {

    private static AlunoJDBC alunoJDBC = new AlunoJDBC();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcao;
        
        do {
            exibirMenu();
            opcao = scanner.nextInt();
            scanner.nextLine(); // Consumir a nova linha

            switch (opcao) {
                case 2:
                    listarAlunos();
                    break;
                case 3:
                    alterarAluno(scanner);
                    break;
                case 4:
                    excluirAluno(scanner);
                    break;
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Op��o inv�lida! Tente novamente.");
                    break;
            }
        } while (opcao != 0);
        
        scanner.close();
    }

    private static void exibirMenu() {
        System.out.println("Menu:");
        System.out.println("2 - Listar Alunos");
        System.out.println("3 - Alterar Aluno");
        System.out.println("4 - Excluir Aluno");
        System.out.println("0 - Sair");
        System.out.print("Escolha uma op��o: ");
    }

    private static void listarAlunos() {
        List<Aluno> alunos = alunoJDBC.listar();
        if (alunos.isEmpty()) {
            System.out.println("Nenhum aluno encontrado.");
        } else {
            for (Aluno aluno : alunos) {
                System.out.println(aluno);
            }
        }
    }

    private static void alterarAluno(Scanner scanner) {
        System.out.print("Digite o ID do aluno a ser alterado: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consumir a nova linha
        
        Aluno aluno = new Aluno();
        aluno.setId(id);
        
        System.out.print("Digite o novo nome: ");
        aluno.setNome(scanner.nextLine());
        
        System.out.print("Digite a nova idade: ");
        aluno.setIdade(scanner.nextInt());
        scanner.nextLine(); // Consumir a nova linha
        
        alunoJDBC.alterar(aluno);
        System.out.println("Aluno alterado com sucesso!");
    }

    private static void excluirAluno(Scanner scanner) {
        System.out.print("Digite o ID do aluno a ser exclu�do: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consumir a nova linha
        
        alunoJDBC.apagar(id);
        System.out.println("Aluno exclu�do com sucesso!");

}
}